import * as s3 from 'aws-cdk-lib/aws-s3';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { type BaseQueueProps } from '../utils/base-queue';
export interface TantivySearchProps {
    /**
     * S3 bucket where indexed emails are stored (shared with incoming emails)
     */
    readonly indexBucket: s3.IBucket;
    /**
     * DynamoDB ItemTable for querying emails
     */
    readonly itemTable: dynamodb.ITable;
    /**
     * DynamoDB ConfigTable for account and mailbox configuration
     */
    readonly configTable: dynamodb.ITable;
    /**
     * DynamoDB ChangelogTable for tracking state changes
     */
    readonly changelogTable: dynamodb.ITable;
    /**
     * Lambda code provider for building/downloading lambdas
     */
    readonly artifactResolver: IArtifactResolver;
    /** Optional default props applied to queues created by this construct (e.g. encryption). */
    readonly queueProps?: Partial<BaseQueueProps>;
}
/**
 * Tantivy search infrastructure:
 * - S3 bucket structure: accounts/{accountId}/search-indexes/account-index.tar.gz
 * - Tantivy Indexer Lambda: triggered by EventBridge every hour per stack
 * - Search is performed in-process by api-handler using tantivysearch Go package
 */
export declare class TantivySearch extends Construct {
    readonly indexer: lambda.Function;
    constructor(scope: Construct, id: string, props: TantivySearchProps);
    /**
     * Get the indexer Lambda ARN
     */
    get indexerArn(): string;
}
