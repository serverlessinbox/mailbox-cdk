import { CfnEnvelope } from './types';
export declare function putCfnResponse(args: {
    cfn: CfnEnvelope;
    status: 'SUCCESS' | 'FAILED';
    physicalResourceId: string;
    data?: Record<string, any>;
    reason?: string;
    logStreamName?: string;
}): Promise<void>;
