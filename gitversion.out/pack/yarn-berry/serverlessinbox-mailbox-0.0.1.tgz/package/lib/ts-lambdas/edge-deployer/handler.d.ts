export declare const starterHandler: (event: any, context: any) => Promise<any>;
export declare const workerHandler: (event: any, context: any) => Promise<any>;
