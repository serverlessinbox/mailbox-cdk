import { CloudFormationClient } from '@aws-sdk/client-cloudformation';
import { OperationInput } from './types';
export declare const cfClient: CloudFormationClient;
export declare function toCfnParameters(parameters?: Record<string, string | undefined>): Array<{
    ParameterKey: string;
    ParameterValue: string;
}>;
export declare function describeStack(stackName: string): Promise<any | undefined>;
export declare function describeRecentFailureEvents(stackName: string, limit?: number): Promise<string[]>;
export declare function safeStringify(value: unknown): string;
export declare function outputsToObject(outputs?: Array<{
    OutputKey?: string;
    OutputValue?: string;
}>): Record<string, string>;
export declare function startOrUpdateStack(op: OperationInput): Promise<void>;
export declare function deleteStackIfExists(stackName: string): Promise<void>;
export declare function isTerminalSuccess(status?: string): boolean;
export declare function isTerminalFailure(status?: string): boolean;
