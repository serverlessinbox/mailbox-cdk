/**
 * CloudFront error response
 */
export declare function createErrorResponse(status: number, message: string): {
    status: string;
    statusDescription: string;
    headers: {
        'content-type': {
            key: string;
            value: string;
        }[];
    };
    body: string;
};
/**
 * Parsed representation of a blob ID.
 */
export type ParsedBlobId = {
    type: 'email';
    entityId: string;
    path: string;
} | {
    type: 'contact';
    entityId: string;
    path: string;
} | {
    type: 'principal';
    entityId: string;
    path: string;
};
/**
 * Parse a blob ID into its type, entity ID and path.
 *
 * Supported formats:
 *   eml:{emailID}:{path}        — email blob
 *   cnt:{contactCardID}:{path}  — contact media blob
 *   prn:{principalID}:{path}    — principal picture blob
 */
export declare function parseBlobId(blobId: string): ParsedBlobId | null;
/**
 * JMAP download URL parameters (spec compliant)
 */
export interface DownloadParams {
    accountId: string;
    blobId: string;
    type?: string;
    name?: string;
}
/**
 * Extract JMAP download parameters from query string
 */
export declare function extractDownloadParams(queryString: string): DownloadParams | null;
/**
 * Construct S3 key from a parsed blob and its owning account.
 */
export declare function constructS3Key(tenantId: string, accountId: string, parsed: ParsedBlobId): string;
/**
 * Add response headers for content type and filename
 */
export declare function addDownloadHeaders(request: any, type?: string, name?: string): void;
