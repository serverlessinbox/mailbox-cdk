/**
 * Lambda@Edge function to authorize blob downloads (JMAP spec compliant)
 *
 * Configuration is passed via custom origin headers:
 * - x-auth-key-store-table: DynamoDB auth key store table name
 * - x-region: AWS region for DynamoDB
 *
 * JMAP Download URL format (RFC 8620):
 * GET /download?accountId={accountId}&blobId={blobId}&type={type}&name={name}
 * Authorization: Bearer <JWT token>
 *
 * Flow:
 * 1. Extract JMAP download parameters (accountId, blobId, type, name)
 * 2. Parse blobId to get emailID and path
 * 3. Verify JWT token and extract user context (userId, accountIds)
 * 4. Verify requested accountId is in user's allowed accountIds
 * 5. Query DynamoDB to get email entity
 * 6. Verify email's accountId matches requested accountId
 * 7. Construct S3 key and add content headers
 * 8. Forward request to S3 origin
 */
export declare const handler: (event: any) => Promise<any>;
