/**
 * Configuration extracted from CloudFront custom origin headers
 * (Lambda@Edge doesn't support environment variables)
 */
export interface Config {
    authKeyStoreTable: string;
    region: string;
    jwtAlgorithms?: string[];
}
export declare function extractConfig(request: any): Config | null;
