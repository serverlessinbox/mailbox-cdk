import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
/**
 * Verify JWT signature and claims without performing any IDP or account DDB lookups.
 * Used in the HMAC path where tenant/account identity comes from the auth token.
 */
export declare function verifyJWTSignatureOnly(token: string, dynamodb: DynamoDBClient, authKeyStoreTable: string, jwtAlgorithms?: string[]): Promise<{
    sub: string;
    issuer: string;
    audience: string;
} | null>;
/**
 * Extract token from Authorization header
 */
export declare function extractToken(authHeader: string | undefined): string | null;
