import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
/**
 * Parsed HMAC token payload
 */
export interface HmacTokenPayload {
    tenantId: string;
    issuer: string;
    audience: string;
    accountIds: string[];
}
/**
 * HMAC signing keys fetched from the JWK cache table
 */
interface HmacKeys {
    current: Buffer;
    previous?: Buffer;
}
/**
 * Fetch HMAC keys from the JWK cache table.
 * Uses module-level cache with 30-minute TTL.
 * Returns null if the item is absent.
 */
export declare function getHmacKeys(dynamodb: DynamoDBClient, authKeyStoreTable: string): Promise<HmacKeys | null>;
/**
 * Verify a single HMAC token against one key.
 *
 * Token format (matches Go signer in session/provider.go):
 *   base64RawURL(payload) + "." + base64RawURL(HMAC-SHA256(key, payload_bytes))
 *   payload_string = "{tenantId}|{issuer}|{audience}|{accountId1,accountId2,...}"
 *
 * Returns the parsed payload on success, or null on any failure.
 */
export declare function verifyHmacToken(token: string, key: Buffer): HmacTokenPayload | null;
/**
 * Verify an HMAC token with key rotation support.
 * Tries the current key first, then falls back to the previous key if present.
 * Returns the parsed payload on success, or null if verification fails.
 */
export declare function verifyHmacTokenWithRotation(token: string, dynamodb: DynamoDBClient, authKeyStoreTable: string): Promise<HmacTokenPayload | null>;
export {};
