export declare function normalizeRelativeKey(input: string): string;
export declare function normalizePrefix(prefix: string, defaultPrefix: string): string;
