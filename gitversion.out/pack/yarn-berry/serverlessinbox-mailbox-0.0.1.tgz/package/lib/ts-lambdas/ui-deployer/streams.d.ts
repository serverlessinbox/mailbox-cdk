export declare function streamToBuffer(stream: AsyncIterable<unknown>): Promise<Buffer>;
