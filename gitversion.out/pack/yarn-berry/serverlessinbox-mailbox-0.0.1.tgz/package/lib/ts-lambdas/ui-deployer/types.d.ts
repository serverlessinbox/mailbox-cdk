export interface UiDeployerResourceProperties {
    deploymentNonce?: string;
    targetBucket: string;
    /** When true, delete ALL objects in the target bucket on stack Delete. */
    clearAllOnDelete?: boolean;
    sourceBucket?: string;
    sourceKey?: string;
    sourceVersionId?: string;
    contentPrefix?: string;
    configPrefix?: string;
    configJson?: string;
    distributionId?: string;
    invalidationPaths?: string[];
}
