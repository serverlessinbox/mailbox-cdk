export declare function guessContentType(key: string): string | undefined;
