export declare function deletePrefix(bucket: string, prefix: string): Promise<number>;
export declare function deployZipToPrefix(params: {
    sourceBucket: string;
    sourceKey: string;
    sourceVersionId?: string;
    targetBucket: string;
    targetPrefix: string;
}): Promise<{
    uploaded: number;
}>;
export declare function writeConfigJson(params: {
    targetBucket: string;
    configPrefix: string;
    configJson?: string;
}): Promise<{
    written: boolean;
}>;
