export declare function invalidateCloudFront(params: {
    distributionId?: string;
    paths?: string[];
    callerReference: string;
}): Promise<{
    invalidated: boolean;
}>;
