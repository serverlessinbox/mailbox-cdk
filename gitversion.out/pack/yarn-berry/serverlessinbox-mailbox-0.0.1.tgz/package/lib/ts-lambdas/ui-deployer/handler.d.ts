export declare const handler: CloudFormationCustomResourceHandler;
