import { Duration } from 'aws-cdk-lib';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
export interface MailboxEdgeDeployerWorkflowProps {
    readonly handler: IFunction;
    /** How long to wait between checks (default: 20s). */
    readonly checkInterval?: Duration;
    /** Overall timeout for the workflow (default: 90m). */
    readonly timeout?: Duration;
    /** Optional explicit state machine name (helps avoid CFN circular deps when referenced elsewhere). */
    readonly stateMachineName?: string;
}
/**
 * CDK Construct wrapper for the edge deployer Step Functions workflow.
 *
 * Exposes the created `stateMachine` so other constructs can wire permissions/env vars
 * without having to think in terms of "loose" factory functions.
 */
export declare class MailboxEdgeDeployerWorkflow extends Construct {
    readonly stateMachine: sfn.StateMachine;
    constructor(scope: Construct, id: string, props: MailboxEdgeDeployerWorkflowProps);
}
/**
 * Creates the Step Functions workflow that drives the long-running edge stack deployment.
 *
 * Input shape:
 * {
 *   cfn: { ResponseURL, StackId, RequestId, LogicalResourceId, ... },
 *   op:  { requestType, stackName, templateUrl, parameters, terminationProtection }
 * }
 */
export declare function createMailboxEdgeDeployerStateMachine(scope: Construct, id: string, props: MailboxEdgeDeployerWorkflowProps): sfn.StateMachine;
