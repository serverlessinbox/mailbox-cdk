import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
import { type ArtifactReference } from '../artifacts/artifact-prefix';
export interface MailboxEdgeConstructProps {
    /** Base domain name, e.g. example.com */
    readonly domainName: string;
    /** Dot-wrapped prefix between endpoint and base domain: "." for none, or ".{label}.". */
    readonly prefix: string;
    /**
     * If provided, the ACM certificate will be DNS-validated automatically via Route53.
     * If omitted, the certificate will use email validation.
     */
    readonly hostedZone?: route53.IHostedZone;
    /** Alternative to hostedZone: import hosted zone by attributes (token-safe). */
    readonly hostedZoneId?: string;
    readonly hostedZoneName?: string;
    /** S3 bucket containing artifacts */
    readonly artifactBucket: string | s3.IBucket;
    /** Blob-authorizer Lambda artifact reference (key + optional S3 version ID) */
    readonly blobAuthorizerReference: ArtifactReference;
    /** DynamoDB item table ARN (regional) used by blob-authorizer */
    readonly itemTableArn: string;
    /** DynamoDB config table ARN (regional) used by blob-authorizer */
    readonly configTableArn: string;
    /** DynamoDB auth key store table ARN (regional) used by blob-authorizer */
    readonly authKeyStoreTableArn: string;
}
/**
 * Creates an ACM certificate and optionally a blob-authorizer Lambda@Edge function.
 *
 * Accepts pre-resolved S3 locations - artifact prefix calculation happens in the deployer.
 */
export declare class MailboxEdgeConstruct extends Construct {
    readonly certificate: acm.Certificate;
    readonly blobAuthorizerFunction: lambda.IFunction;
    readonly blobAuthorizerVersion: lambda.IVersion;
    constructor(scope: Construct, id: string, props: MailboxEdgeConstructProps);
}
