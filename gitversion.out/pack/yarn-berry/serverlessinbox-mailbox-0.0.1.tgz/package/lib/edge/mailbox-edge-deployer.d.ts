import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface MailboxEdgeDeployerProps {
    /**
     * Artifact resolver for loading Lambda code and artifact locations from S3
     */
    readonly artifactResolver: IArtifactResolver;
    /** Base domain name (e.g. example.com) */
    readonly domainName: string;
    /** Optional prefix between endpoint and base domain (e.g. "mailbox" -> admin.mailbox.example.com) */
    readonly prefix?: string;
    /** Route53 hosted zone ID for DNS validation (optional) */
    readonly hostedZoneId?: string;
    /** Route53 hosted zone name (required if hostedZoneId is provided) */
    readonly hostedZoneName?: string;
    /** Whether to enable termination protection on the edge stack (default: false) */
    readonly terminationProtection?: boolean;
    /** DynamoDB item table ARN (regional) used by blob-authorizer */
    readonly itemTableArn: string;
    /** DynamoDB config table ARN (regional) used by blob-authorizer */
    readonly configTableArn: string;
    /** DynamoDB auth key store table ARN (regional) used by blob-authorizer */
    readonly authKeyStoreTableArn: string;
    /** Optional product/stack version used for tagging edge resources. */
    readonly productVersion?: string;
    /** Optional deployer label used for tagging (default: 'cfn'). */
    readonly deployer?: 'cdk' | 'cfn' | 'marketplace';
}
/**
 * Deploys the MailboxEdgeStack to us-east-1 from a versioned/channeled template in S3,
 * and exposes its Outputs back into the current (regional) stack.
 */
export declare class MailboxEdgeDeployer extends Construct {
    readonly edgeStackId: string;
    /** Published Lambda@Edge version for blob authorization (always present). */
    readonly blobAuthorizerVersion: lambda.IVersion;
    /** us-east-1 ACM certificate for CloudFront (only when hosted zone info is provided). */
    readonly edgeCertificate?: acm.ICertificate;
    /** Exposes the raw output map (access via getOutput). */
    private readonly resource;
    constructor(scope: Construct, id: string, props: MailboxEdgeDeployerProps);
    /** Read a specific CloudFormation output (OutputKey) from the deployed edge stack. */
    getOutput(outputKey: string): string;
}
