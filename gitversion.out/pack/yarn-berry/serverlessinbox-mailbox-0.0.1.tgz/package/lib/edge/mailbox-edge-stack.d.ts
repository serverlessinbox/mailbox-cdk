import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { MailboxEdgeConstruct } from './mailbox-edge-construct';
export interface MailboxEdgeStackProps extends cdk.StackProps {
}
/**
 * Deploy this stack in us-east-1.
 *
 * Creates CloudFormation parameters for domain configuration and S3 artifact locations,
 * and instantiates the MailboxEdgeConstruct.
 */
export declare class MailboxEdgeStack extends cdk.Stack {
    readonly construct: MailboxEdgeConstruct;
    constructor(scope: Construct, id: string, props: MailboxEdgeStackProps);
}
