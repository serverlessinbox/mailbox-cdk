/**
 * @mailbox/cdk - CDK Construct Library for Mailbox Infrastructure
 */
export { Mailbox } from './mailbox';
export type { MailboxProps, MailboxOAuthClients } from './mailbox';
export { DEFAULT_OIDC_PROVIDER_NAME, AUTH_POLICY_ADMIN_API, AUTH_POLICY_JMAP_API, OAUTH_CLIENT_ADMIN_UI, OAUTH_CLIENT_JMAP_UI, } from './auth/types';
export type { AuthPolicyName, OAuthClientName, AuthMethod, OidcProviderConfig, AuthPolicyConfig, AuthPoliciesConfig, MailboxAuthPolicies, OAuthClientCredentials, OAuthFlow, OAuthAuthorizationCodeClientConfig, OAuthClientCredentialsClientConfig, OAuthClientConfig, OAuthClientsConfig, GenerateClientParams, AuthClientConfig, ProvisionAdminUiClientParams, ProvisionJmapUiClientParams, IMailboxAuthProviderBase, IAdminUiConfigProvider, MailboxRole, MailboxAuthorizationConfig, IMailboxAuthorizationConfigProvider, IMailboxAuthProvider, } from './auth/types';
export { Permission, JMAP_SCOPE_DESCRIPTIONS } from './auth/jmap-scopes';
export type { IAdminApiAddon, AdminApiAddonContext, IAdminApiAddonProvider } from './api/addons';
export { ArtifactResolver } from './artifacts/artifact-resolver';
export type { ReleaseTarget, ChannelTarget, TrackTarget, PublishTarget, IArtifactResolver, ArtifactResolverConfig, } from './artifacts/artifact-resolver';
export { createArtifactResolverFromContext } from './artifacts/artifact-context';
export type { ArtifactReference } from './artifacts/artifact-prefix';
export { getArtifactPrefix, getEdgeArtifactPrefix, getArtifactUrl, getEdgeArtifactUrl, } from './artifacts/artifact-prefix';
export { DEVELOPMENT_CONTEXT_KEYS, isDevelopmentMode, removalPolicyForRetainedResources, autoDeleteObjectsInDevelopment, } from './utils/development-mode';
export type { MailboxKmsMode, MailboxKmsResource, MailboxKmsPerResourceConfig, MailboxKmsConfig, } from './utils/kms';
export { mailboxKmsMode, mailboxKmsDisabled, mailboxKmsExcluded, resolveEmailBucketKey, resolveDynamoTablesKey, resolveQueuesKey, } from './utils/kms';
