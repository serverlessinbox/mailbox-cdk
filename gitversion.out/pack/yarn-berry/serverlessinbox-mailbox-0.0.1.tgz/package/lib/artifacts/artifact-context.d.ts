import { IConstruct } from 'constructs';
import { ArtifactResolver } from './artifact-resolver';
/**
 * Creates an ArtifactResolver from CDK context values.
 *
 * Context key: `artifacts` (required)
 *
 * Structure:
 * ```json
 * {
 *   "bucketBase": "mailbox-artifacts",
 *   "packages": {
 *     "mailbox-cdk": { "kind": "release", "version": "1.2.3" },
 *     "mailbox-go": { "kind": "channel", "channel": "dev" }
 *   }
 * }
 * ```
 *
 * Optional context key: `artifactVersions` (for versioned URLs in channels)
 * Map of S3 keys to version IDs: `{ "packages/mailbox-go/channels/dev/lambdas/handler.zip": "abc123" }`
 */
export declare function createArtifactResolverFromContext(scope: IConstruct): ArtifactResolver;
