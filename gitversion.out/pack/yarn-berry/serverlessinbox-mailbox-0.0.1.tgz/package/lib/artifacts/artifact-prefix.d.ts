/**
 * Utilities for artifact path naming based on S3 structure in artifacts.md
 */
import type { PublishTarget } from './artifact-resolver';
export type { PublishTarget };
export interface ArtifactReference {
    /** Artifact path relative to the publish target prefix, e.g. "template.json" or "lambdas/blob-authorizer.zip" */
    readonly key: string;
    /** Optional S3 object version ID */
    readonly s3VersionId?: string;
}
/**
 * Builds the artifact prefix for a package following the S3 naming convention.
 *
 * - Release: `packages/{packageName}/v{version}`
 * - Channel: `packages/{packageName}/channels/{channel}`
 */
export declare function getArtifactPrefix(target: PublishTarget, packageName?: string): string;
/**
 * Builds the artifact prefix for edge resources (mailbox-cdk-edge package).
 * Edge resources are always deployed to us-east-1.
 *
 * - Release: `packages/mailbox-cdk-edge/v{version}`
 * - Channel: `packages/mailbox-cdk-edge/channels/{channel}`
 */
export declare function getEdgeArtifactPrefix(target: PublishTarget): string;
/**
 * Builds a full S3 HTTPS URL for an artifact.
 *
 * @param bucket S3 bucket name (without region suffix)
 * @param target Publish target (release or channel)
 * @param reference Artifact reference with key and optional version ID
 * @param packageName Package name (defaults to mailbox-cdk)
 * @returns Full HTTPS URL, optionally with ?versionId query param
 */
export declare function getArtifactUrl(bucket: string, target: PublishTarget, reference: ArtifactReference, packageName?: string): string;
/**
 * Builds a full S3 HTTPS URL for an edge artifact.
 *
 * @param bucket S3 bucket name (without region suffix)
 * @param target Publish target (release or channel)
 * @param reference Artifact reference with key and optional version ID
 * @returns Full HTTPS URL, optionally with ?versionId query param
 */
export declare function getEdgeArtifactUrl(bucket: string, target: PublishTarget, reference: ArtifactReference): string;
