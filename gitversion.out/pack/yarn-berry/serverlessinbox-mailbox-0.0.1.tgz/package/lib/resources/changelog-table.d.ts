import { Construct } from 'constructs';
import { StackNamedTable } from '../utils/named-table';
import type { TableProps } from 'aws-cdk-lib/aws-dynamodb';
/**
 * DynamoDB table for changelog and state management
 *
 * Optimized structure:
 * PK: {accountId}#{objectType}        e.g., "acc_xxx#Email"
 * SK: {state}                          e.g., 156 (number)
 *
 * State counter (SK=0):
 * - v: current state value (number)
 *
 * Changelog entries (SK>0):
 * - o: objectId (string)
 * - c: changeType (c/u/d)
 * - x: expiresAt (TTL)
 */
export declare class ChangelogTable extends StackNamedTable {
    constructor(scope: Construct, props?: Partial<TableProps>);
}
