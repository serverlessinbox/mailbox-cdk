import { Construct } from 'constructs';
import { StackNamedTable } from '../utils/named-table';
import { IGrantable } from 'aws-cdk-lib/aws-iam';
import type { TableProps } from 'aws-cdk-lib/aws-dynamodb';
/**
 * DynamoDB table for audit log
 *
 * Structure:
 * PK: AUDIT#{entityType}#{entityId}
 * SK: TIMESTAMP#{timestamp}
 * GSI1PK: ACTOR#{userId}
 * GSI1SK: TIMESTAMP#{timestamp}
 *
 */
export declare class AuditLogTable extends StackNamedTable {
    constructor(scope: Construct, props?: Partial<TableProps>);
    grantReadAccess(grantee: IGrantable): void;
}
