import { BucketEncryption } from "aws-cdk-lib/aws-s3";
import { Construct } from "constructs";
import { StackNamedBucket } from "../utils/named-bucket";
import type * as kms from 'aws-cdk-lib/aws-kms';
export interface EmailBucketProps {
    /**
     * Optional explicit bucket encryption setting.
     * If omitted, defaults to SSE-KMS (AWS-managed) unless an encryptionKey is provided.
     */
    readonly encryption?: BucketEncryption;
    /** Optional customer-managed CMK to use for SSE-KMS. */
    readonly encryptionKey?: kms.IKey;
}
export declare class EmailBucket extends StackNamedBucket {
    constructor(scope: Construct, props?: EmailBucketProps);
}
