import { Construct } from "constructs";
import { StackNamedTable } from "../utils/named-table";
import type { TableProps } from 'aws-cdk-lib/aws-dynamodb';
export declare class ItemTable extends StackNamedTable {
    constructor(scope: Construct, props?: Partial<TableProps>);
}
