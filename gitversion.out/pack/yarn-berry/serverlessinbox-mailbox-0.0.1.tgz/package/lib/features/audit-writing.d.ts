import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { BaseQueue, type BaseQueueProps } from '../utils/base-queue';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface AuditWritingProps {
    readonly auditLogTable: ITable;
    readonly artifactResolver: IArtifactResolver;
    /** Optional default props applied to all queues created by this construct (e.g. encryption). */
    readonly queueProps?: Partial<BaseQueueProps>;
}
/**
 * Audit Writing Infrastructure
 *
 * Creates an SQS queue for audit events and a consumer Lambda (audit-writer).
 */
export declare class AuditWriting extends Construct {
    readonly auditEventsQueue: BaseQueue;
    readonly auditEventsDlq: BaseQueue;
    readonly auditWriterLambda: lambda.IFunction;
    constructor(scope: Construct, id: string, props: AuditWritingProps);
}
