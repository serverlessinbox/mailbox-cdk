import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { BootstrapLambda } from '../lambdas';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { AuthPoliciesConfig, OAuthClientsConfig, OidcProviderConfig } from '../auth/types';
export interface BootstrapProps {
    readonly configTable: ITable;
    readonly jwkCacheTable: ITable;
    readonly authKeyStoreTable: ITable;
    readonly tenantName?: string;
    readonly defaultLocalPart?: string;
    readonly domain: string;
    readonly oidcIssuer: string;
    readonly oidcProviderName?: string;
    readonly oidcProvider?: OidcProviderConfig;
    readonly authPolicies?: AuthPoliciesConfig;
    readonly oauthClients?: OAuthClientsConfig;
    readonly artifactResolver: IArtifactResolver;
    readonly sesRuleSetName?: string;
}
/**
 * CDK Construct for bootstrapping a new tenant.
 */
export declare class Bootstrap extends Construct {
    /** The Lambda function backing the bootstrap custom resource. */
    readonly handler: BootstrapLambda;
    constructor(scope: Construct, id: string, props: BootstrapProps);
}
export type { OidcProviderConfig, AuthPoliciesConfig, OAuthClientsConfig, } from '../auth/types';
