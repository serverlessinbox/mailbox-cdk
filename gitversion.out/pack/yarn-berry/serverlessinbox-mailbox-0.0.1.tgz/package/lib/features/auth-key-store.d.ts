import { Construct } from 'constructs';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { INamedTable } from '../utils/named-table';
import { IFunction } from 'aws-cdk-lib/aws-lambda';
export interface AuthKeyStoreProps {
    readonly issuers: string[];
    /**
     * Artifact resolver for building/downloading lambdas
     */
    readonly artifactResolver: IArtifactResolver;
}
export declare class AuthKeyStore extends Construct {
    table: INamedTable;
    tableName: string;
    updaterLambda: IFunction;
    constructor(scope: Construct, id: string, props: AuthKeyStoreProps);
}
