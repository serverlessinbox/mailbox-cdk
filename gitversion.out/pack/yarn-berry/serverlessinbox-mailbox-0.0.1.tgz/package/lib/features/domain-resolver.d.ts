export { MailboxDomains, IMailboxDomainNames, MailboxDomainNamesProps, MailboxDomainContext, MailboxDomainContextProps, MailboxDns, MailboxDnsProps, MailboxEndpoint, MAILBOX_ENDPOINTS, } from '../domains';
import { MailboxDomains } from '../domains';
import type { MailboxDomainNamesProps } from '../domains';
export type DomainResolverProps = MailboxDomainNamesProps;
export declare const DomainResolver: typeof MailboxDomains;
