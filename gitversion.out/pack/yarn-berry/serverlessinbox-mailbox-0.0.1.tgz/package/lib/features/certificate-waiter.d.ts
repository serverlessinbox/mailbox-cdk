import { ICertificate } from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
import { CertWaiterLambda } from '../lambdas';
export interface CertificateWaiterProps {
    /** The certificate to wait for disassociation on delete. */
    readonly certificate: ICertificate;
    /** The cert-waiter Lambda function to use as the custom resource service token. */
    readonly certWaiterLambda: CertWaiterLambda;
}
export declare class CertificateWaiter extends Construct {
    constructor(scope: Construct, id: string, props: CertificateWaiterProps);
}
