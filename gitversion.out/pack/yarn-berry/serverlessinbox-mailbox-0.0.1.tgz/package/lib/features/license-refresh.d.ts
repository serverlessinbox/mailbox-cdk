import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface LicenseRefreshProps {
    readonly configTable: ITable;
    readonly artifactResolver: IArtifactResolver;
}
export declare class LicenseRefresh extends Construct {
    /** Exposed for constructs that need to gate on the license function (e.g. McpApi). */
    readonly licenseFunction: lambda.IFunction;
    constructor(scope: Construct, id: string, props: LicenseRefreshProps);
}
