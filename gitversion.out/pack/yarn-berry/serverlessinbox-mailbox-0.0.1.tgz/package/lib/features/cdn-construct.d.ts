import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { INamedBucket } from '../utils/named-bucket';
import { INamedTable } from '../utils/named-table';
export interface CdnProps {
    readonly emailBucket: INamedBucket;
    readonly configTable: INamedTable;
    readonly authKeyStoreTable: INamedTable;
    readonly userPoolIssuer: string;
    readonly allowedOrigins?: string[];
    readonly jwtAlgorithms?: string[];
    /** Pre-deployed Lambda@Edge version (us-east-1). */
    readonly blobAuthorizerVersion: lambda.IVersion;
    /** Optional custom domain name for the CDN distribution (e.g., cdn.example.com). */
    readonly domainName?: string;
    /** Optional us-east-1 ACM certificate for the custom domain name. */
    readonly certificate?: acm.ICertificate;
}
export declare class Cdn extends Construct {
    readonly distribution: cloudfront.Distribution;
    readonly host: string;
    readonly distributionId: string;
    constructor(scope: Construct, id: string, props: CdnProps);
}
