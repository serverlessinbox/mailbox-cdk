import { Construct } from 'constructs';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { Distribution } from 'aws-cdk-lib/aws-cloudfront';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { AuthPolicyName, OAuthClientName } from '../auth/types';
export type UiBundleSource = {
    packageName: string;
    objectPath: string;
};
export interface MailboxUiProps {
    /** Domain name for the CloudFront distribution (e.g., admin.example.com) */
    domainName: string;
    /** Optional ACM certificate for `domainName`. */
    certificate?: acm.ICertificate;
    /** Shared config table used by token exchange API. */
    configTable: ITable;
    /** Which auth policy record to use for token exchange. */
    authPolicyName: AuthPolicyName;
    /** Which OAuth client record to use for token exchange. */
    oauthClientName: OAuthClientName;
    /** Optional audit events queue for publishing audit logs from token exchange. */
    auditEventsQueue?: IQueue;
    /** Human-friendly label used for CloudFront comments. */
    label: string;
    /** Optional UI bundle (zip) published as an artifact. Deployed to `s3://<ui-bucket>/content/` via custom resource. */
    uiBundle?: UiBundleSource;
    /** Optional UI runtime config written to `s3://<ui-bucket>/config/config.json` via custom resource. */
    uiConfig?: {
        /** Base URL for the UI's backend API (whatever the frontend consumes). */
        apiUrl?: string;
        /** Additional provider-/deployment-specific config for the UI. */
        [key: string]: unknown;
    };
}
/**
 * Shared UI construct used by Admin UI and Webmail UI.
 *
 * Creates:
 * - S3 bucket for static assets
 * - CloudFront distribution
 * - /auth/* behavior routed to token exchange API
 */
export declare class MailboxUi extends Construct {
    readonly bucket: Bucket;
    readonly distribution: Distribution;
    readonly distributionDomainName: string;
    private getOrCreateUiDeployer;
    constructor(scope: Construct, id: string, props: MailboxUiProps);
    private addUiDeployment;
    private addAuthBehavior;
}
