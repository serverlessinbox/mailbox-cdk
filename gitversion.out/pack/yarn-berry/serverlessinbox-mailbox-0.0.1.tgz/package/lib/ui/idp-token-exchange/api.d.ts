import { HttpApi } from "aws-cdk-lib/aws-apigatewayv2";
import { Construct } from "constructs";
import { IArtifactResolver } from "../../artifacts/artifact-resolver";
import { ITable } from "aws-cdk-lib/aws-dynamodb";
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { AuthPolicyName, OAuthClientName } from "../../auth/types";
export interface IdpTokenExchangeApiProps {
    artifactResolver: IArtifactResolver;
    configTable: ITable;
    auditEventsQueue?: IQueue;
    /**
     * Name of AUTH_POLICY record to use (e.g. ADMIN_API).
     */
    authPolicyName?: AuthPolicyName;
    /**
     * Name of OAUTH_CLIENT record to use (e.g. ADMIN_UI).
     */
    oauthClientName?: OAuthClientName;
}
export declare class IdpTokenExchangeApi extends Construct {
    readonly api: HttpApi;
    constructor(scope: Construct, id: string, props: IdpTokenExchangeApiProps);
}
