import { Construct } from 'constructs';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { Distribution } from 'aws-cdk-lib/aws-cloudfront';
import { ITable } from "aws-cdk-lib/aws-dynamodb";
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { AuthClientConfig, IMailboxAuthProvider } from "../auth/types";
import { UiBundleSource } from './mailbox-ui';
export interface WebmailUiProps {
    /**
     * Domain name for the CloudFront distribution (e.g., webmail.example.com)
     */
    readonly domainName: string;
    /**
     * Optional ACM certificate for `domainName`.
     * When provided, the CloudFront distribution will be configured with an alternate domain name.
     */
    readonly certificate?: acm.ICertificate;
    /**
     * Shared config table used by token exchange API.
     */
    readonly configTable: ITable;
    /** Auth provider used to provision the OAuth client for this UI. */
    readonly authProvider: IMailboxAuthProvider;
    /** Optional audit events queue for publishing audit logs from token exchange. */
    readonly auditEventsQueue?: IQueue;
    /** Optional UI bundle (zip) published as an artifact. Deployed to `s3://<ui-bucket>/content/` via custom resource. */
    readonly uiBundle?: UiBundleSource;
    /** Base URL for the Webmail UI's backend API. Written into `/config/config.json`. */
    readonly apiUrl?: string;
}
export declare class WebmailUi extends Construct {
    readonly bucket: Bucket;
    readonly distribution: Distribution;
    readonly distributionDomainName: string;
    readonly oauthClient: AuthClientConfig;
    readonly oauthRedirectUri: string;
    constructor(scope: Construct, id: string, props: WebmailUiProps);
}
