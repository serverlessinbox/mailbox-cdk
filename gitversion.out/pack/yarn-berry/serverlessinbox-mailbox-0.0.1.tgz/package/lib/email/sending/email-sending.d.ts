import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { BaseQueue, type BaseQueueProps } from '../../utils/base-queue';
import { IArtifactResolver } from '../../artifacts/artifact-resolver';
import type { IWebSocketBroadcastPublisher } from '../../api/websocket';
export interface EmailSendingProps {
    readonly configTable: ITable;
    readonly itemTable: ITable;
    readonly changelogTable: ITable;
    readonly emailBucket: IBucket;
    readonly artifactResolver: IArtifactResolver;
    readonly sesConfigSetName: string;
    /** Optional default props applied to all queues created by this construct (e.g. encryption). */
    readonly queueProps?: Partial<BaseQueueProps>;
}
/**
 * Email Sending Infrastructure
 *
 * Creates the SQS queue for email submissions with a DLQ.
 * SES event processing is handled by the separate SESEventProcessing module.
 */
export declare class EmailSending extends Construct {
    readonly submissionQueue: BaseQueue;
    readonly submissionDlq: BaseQueue;
    readonly emailSenderLambda: lambda.Function;
    constructor(scope: Construct, id: string, props: EmailSendingProps);
    enableWebSocketPublishing(broadcaster: IWebSocketBroadcastPublisher): void;
}
