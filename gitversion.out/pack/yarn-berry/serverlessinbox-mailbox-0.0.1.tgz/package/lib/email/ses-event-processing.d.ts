import { Topic } from 'aws-cdk-lib/aws-sns';
import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { BaseQueue, type BaseQueueProps } from '../utils/base-queue';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import type { IWebSocketBroadcastPublisher } from '../api/websocket';
export interface SESEventProcessingProps {
    readonly itemTable: ITable;
    readonly changelogTable: ITable;
    readonly mailFeedbackTable: ITable;
    readonly configTable: ITable;
    readonly emailBucket: IBucket;
    readonly auditEventsQueue: IQueue;
    readonly artifactResolver: IArtifactResolver;
    /** Optional default props applied to all queues created by this construct (e.g. encryption). */
    readonly queueProps?: Partial<BaseQueueProps>;
}
/**
 * SES Event Processing Infrastructure
 *
 * Handles SES events (bounce, complaint, delivery, send, reject) through:
 * - SNS topic for SES notifications
 * - SQS queue to consume SNS notifications
 * - Lambda to process SES events
 * - SES Configuration Set for event routing
 */
export declare class SESEventProcessing extends Construct {
    readonly sesNotificationsTopic: Topic;
    readonly sesNotificationsQueue: BaseQueue;
    readonly sesEventProcessorLambda: lambda.Function;
    readonly sesConfigSetName: string;
    constructor(scope: Construct, id: string, props: SESEventProcessingProps);
    enableWebSocketPublishing(broadcaster: IWebSocketBroadcastPublisher): void;
}
