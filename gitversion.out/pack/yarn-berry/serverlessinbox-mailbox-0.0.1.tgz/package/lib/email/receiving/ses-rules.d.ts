import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
import { type BaseQueueProps } from '../../utils/base-queue';
import { IArtifactResolver } from '../../artifacts/artifact-resolver';
export interface EmailDelivery {
    readonly emailBucket: IBucket;
    readonly emailProcessor: IFunction;
    readonly bucketPrefix: string;
    readonly artifactResolver: IArtifactResolver;
    /** Encryption props forwarded from the mailbox encryption plan. */
    readonly queueProps?: Partial<BaseQueueProps>;
}
export interface SesRulesProps {
    readonly delivery: EmailDelivery;
    readonly activateReceiving?: boolean;
}
export declare class SesRules extends Construct {
    /** The name of the SES receipt rule set created by this construct. */
    readonly ruleSetName: string;
    constructor(scope: Construct, id: string, props: SesRulesProps);
}
