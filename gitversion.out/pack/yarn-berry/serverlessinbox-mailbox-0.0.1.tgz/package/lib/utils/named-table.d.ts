import { ITable, TableProps } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
import { BaseTable } from './base-table';
export interface INamedTable extends ITable {
    readonly explicitTableName: string;
}
export declare class StackNamedTable extends BaseTable implements INamedTable {
    readonly explicitTableName: string;
    constructor(scope: Construct, tableName: string, props: TableProps);
}
