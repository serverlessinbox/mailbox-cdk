import { Construct } from 'constructs';
import { Queue, QueueProps } from 'aws-cdk-lib/aws-sqs';
import { Duration } from 'aws-cdk-lib';
export interface BaseQueueProps extends Omit<QueueProps, 'visibilityTimeout' | 'receiveMessageWaitTime'> {
    /**
     * Optional custom visibility timeout (default: 5 minutes)
     */
    visibilityTimeout?: Duration;
    /**
     * Optional custom receive message wait time (default: 20 seconds for long polling)
     */
    receiveMessageWaitTime?: Duration;
}
/**
 * Base Queue construct with standard settings for Mailbox
 *
 * Provides sensible defaults:
 * - Visibility timeout: 5 minutes
 * - Long polling: 20 seconds
 */
export declare class BaseQueue extends Queue {
    constructor(scope: Construct, id: string, props?: BaseQueueProps);
}
