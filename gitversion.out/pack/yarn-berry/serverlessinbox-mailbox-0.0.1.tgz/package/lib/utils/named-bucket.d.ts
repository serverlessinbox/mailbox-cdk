import { Bucket, BucketProps, IBucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface INamedBucket extends IBucket {
    readonly explicitBucketName: string;
}
export declare class StackNamedBucket extends Bucket implements INamedBucket {
    readonly explicitBucketName: string;
    constructor(scope: Construct, bucketName: string, props?: BucketProps);
}
