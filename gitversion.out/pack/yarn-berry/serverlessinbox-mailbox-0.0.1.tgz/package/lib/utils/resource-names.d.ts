import type { IConstruct } from 'constructs';
export interface PhysicalNameOptions {
    /** Hard cap for services with strict limits (e.g. Lambda 64, S3 63). */
    maxLength?: number;
}
/**
 * Create a stable, customer-friendly physical name that follows the existing scheme:
 * `<account>-<sanitize(stackName)>-<suffix>`.
 */
export declare function makePhysicalName(scope: IConstruct, suffix: string, options?: PhysicalNameOptions): string;
/** Convenience for turning labels like "Admin UI" into "admin-ui". */
export declare function slugifyLabel(label: string): string;
