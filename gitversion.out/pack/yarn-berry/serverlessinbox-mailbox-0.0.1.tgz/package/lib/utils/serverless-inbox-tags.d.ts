import type { IConstruct } from 'constructs';
export type ServerlessInboxComponent = 'auth' | 'ui' | 'edge' | 'api' | 'email' | 'storage' | 'search' | 'messaging';
export type ServerlessInboxDeployer = 'cdk' | 'cfn' | 'marketplace';
export declare const ServerlessInboxTagKeys: {
    readonly product: "serverless-inbox:product";
    readonly deployment: "serverless-inbox:deployment";
    readonly component: "serverless-inbox:component";
    readonly version: "serverless-inbox:version";
    readonly deployer: "serverless-inbox:deployer";
    readonly edge: "serverless-inbox:edge";
    readonly originDeployment: "serverless-inbox:origin-deployment";
    readonly originRegion: "serverless-inbox:origin-region";
};
export interface ApplyServerlessInboxTagsOptions {
    /** Defaults to 'mailbox'. */
    product?: string;
    /** Defaults to AWS::StackName (the deployed stack name). */
    deployment?: string;
    /** Optional version string (e.g. '1.2.3' or 'channel:dev'). */
    version?: string;
    /** Optional deployer kind ('cfn' by default if provided). */
    deployer?: ServerlessInboxDeployer;
    /** Optional extra tags supplied by the caller. */
    extraTags?: Record<string, string>;
}
export interface ApplyServerlessInboxEdgeTagsOptions {
    originDeployment: string;
    originRegion: string;
}
export declare function applyServerlessInboxBaseTags(scope: IConstruct, options?: ApplyServerlessInboxTagsOptions): void;
export declare function applyServerlessInboxComponentTag(scope: IConstruct, component: ServerlessInboxComponent): void;
export declare function applyServerlessInboxEdgeTags(scope: IConstruct, options: ApplyServerlessInboxEdgeTagsOptions): void;
