import { FunctionOptions, Function as LambdaFunction } from 'aws-cdk-lib/aws-lambda';
import { RetentionDays } from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface GoLambda2Props extends FunctionOptions {
    /**
     * Lambda identifier used by code provider (e.g., "authorizer", "api-handler")
     */
    lambdaId: string;
    /**
     * Code provider for obtaining lambda code asset
     */
    artifactResolver: IArtifactResolver;
    /**
     * Log retention policy for the lambda's default log group.
     * Set to `false` to skip log retention management.
     *
     * Default: ONE_MONTH.
     */
    logGroupRetention?: RetentionDays | false;
}
/** @internal */
export declare class GoLambda extends LambdaFunction {
    constructor(scope: Construct, id: string, props: GoLambda2Props);
}
