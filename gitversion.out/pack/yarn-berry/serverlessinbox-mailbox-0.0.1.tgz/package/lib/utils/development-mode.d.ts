import { RemovalPolicy } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export declare const DEVELOPMENT_CONTEXT_KEYS: readonly ["development", "mailbox:development"];
/**
 * Returns true when CDK context enables development mode.
 *
 * Supported context keys:
 * - `development=true`
 * - `mailbox:development=true`
 */
export declare function isDevelopmentMode(scope: Construct): boolean;
/**
 * Removal policy to use for resources that are normally retained.
 * In development mode, this flips to DESTROY to make `cdk destroy` clean.
 */
export declare function removalPolicyForRetainedResources(scope: Construct): RemovalPolicy;
/**
 * Whether S3 buckets should automatically delete objects.
 * Intended to be enabled in development mode only.
 */
export declare function autoDeleteObjectsInDevelopment(scope: Construct): boolean;
