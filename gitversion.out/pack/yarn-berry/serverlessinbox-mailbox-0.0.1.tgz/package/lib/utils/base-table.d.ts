import { GlobalSecondaryIndexProps, Table, TableProps } from 'aws-cdk-lib/aws-dynamodb';
import { Grant, IGrantable } from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
/**
 * Base DynamoDB table construct with on-demand billing by default
 * All new DynamoDB tables should extend this class to ensure consistent configuration
 */
export declare class BaseTable extends Table {
    gsiIndexNames: string[];
    constructor(scope: Construct, id: string, props: TableProps);
    addGlobalSecondaryIndex(props: GlobalSecondaryIndexProps): void;
    grantReadData(grantee: IGrantable): Grant;
    grantWriteData(grantee: IGrantable): Grant;
}
