import { Construct } from 'constructs';
import { type TableProps } from 'aws-cdk-lib/aws-dynamodb';
import type { EmailBucketProps } from '../resources/email-bucket';
import type { BaseQueueProps } from './base-queue';
import type { MailboxKmsConfig } from './kms';
export interface MailboxEncryptionPlan {
    readonly emailBucket: EmailBucketProps;
    readonly dynamoTables: Partial<TableProps>;
    /**
     * Default props for queues created via BaseQueue.
     * - `undefined` means "use BaseQueue defaults".
     */
    readonly queues?: Partial<BaseQueueProps>;
}
export declare function resolveMailboxEncryptionPlan(scope: Construct, kms?: MailboxKmsConfig): MailboxEncryptionPlan;
