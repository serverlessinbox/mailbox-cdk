import { Construct } from 'constructs';
import * as kms from 'aws-cdk-lib/aws-kms';
export type MailboxKmsMode = 'aws-managed' | 'customer-managed';
export type MailboxKmsResource = 's3' | 'dynamodb' | 'sqs';
export interface MailboxKmsPerResourceConfig {
    readonly emailBucket?: kms.IKey;
    readonly dynamoTables?: kms.IKey;
    readonly queues?: kms.IKey;
}
export interface MailboxKmsConfig {
    /**
     * Default: 'aws-managed'
     * - 'none': do not use KMS for resources that support disabling it (S3/SQS); DynamoDB uses AWS-owned encryption.
     * - 'aws-managed': use AWS-managed keys (e.g. alias/aws/s3)
     * - 'customer-managed': use customer-managed CMK(s) provided below
     */
    readonly mode?: MailboxKmsMode | 'none';
    /**
     * Exclude specific resources from KMS usage.
     * Example: { mode: 'aws-managed', excluded: ['s3'] } keeps S3 on SSE-S3, while Dynamo/SQS remain KMS-encrypted.
     */
    readonly excluded?: MailboxKmsResource[];
    /**
     * Optional “one key for core resources” (regional).
     * Used when mode='customer-managed' and a perResource key isn't set.
     */
    readonly key?: kms.IKey;
    /** Optional per-resource overrides. */
    readonly perResource?: MailboxKmsPerResourceConfig;
}
export declare function mailboxKmsMode(config?: MailboxKmsConfig): MailboxKmsMode;
export declare function mailboxKmsDisabled(config?: MailboxKmsConfig): boolean;
export declare function mailboxKmsExcluded(resource: MailboxKmsResource, config?: MailboxKmsConfig): boolean;
export declare function resolveEmailBucketKey(scope: Construct, config?: MailboxKmsConfig): kms.IKey | undefined;
export declare function resolveDynamoTablesKey(scope: Construct, config?: MailboxKmsConfig): kms.IKey | undefined;
export declare function resolveQueuesKey(scope: Construct, config?: MailboxKmsConfig): kms.IKey | undefined;
