import { Construct } from 'constructs';
import { Table } from 'aws-cdk-lib/aws-dynamodb';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import type { IGrantable } from 'aws-cdk-lib/aws-iam';
export interface IWebSocketBroadcastPublisher {
    readonly functionName: string;
    grantInvoke(grantee: IGrantable): void;
}
export interface WebSocketPushProps {
    readonly configTable: ITable;
    readonly itemTable: ITable;
    readonly changelogTable: ITable;
    readonly authKeyStoreTable: ITable;
    readonly authorizerLambda: lambda.IFunction;
    readonly artifactResolver: IArtifactResolver;
    readonly maxSubscriptions?: number;
    /** Optional custom domain name (e.g. ws.example.com). When set, a domain mapping is created. */
    readonly domainName?: string;
    /** ACM certificate for domainName (must be regional, in the same region as the stack/API). */
    readonly certificate?: acm.ICertificate;
}
export declare class WebSocketPush extends Construct {
    readonly webSocketUrl: string;
    /** CNAME target to publish (API Gateway regional domain) when custom domain is enabled. */
    readonly domainTarget?: string;
    readonly connectionsTable: Table;
    private readonly broadcastLambda;
    readonly broadcaster: IWebSocketBroadcastPublisher;
    constructor(scope: Construct, id: string, props: WebSocketPushProps);
}
