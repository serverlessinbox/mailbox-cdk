import { Construct } from 'constructs';
import { HttpApi } from 'aws-cdk-lib/aws-apigatewayv2';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { IMailboxAuthProvider } from '../auth/types';
import { GoLambda } from '../utils/go-lambda';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import type { IWebSocketBroadcastPublisher } from './websocket';
export interface JMapApiProps {
    readonly configTable: ITable;
    readonly itemTable: ITable;
    readonly changelogTable: ITable;
    readonly authKeyStoreTable: ITable;
    readonly emailBucket: IBucket;
    readonly emailSubmissionQueue: IQueue;
    readonly auditEventsQueue: IQueue;
    /** OAuth clientId to advertise in the JMAP session response (must be JMAP_UI). */
    readonly oauthClientId: string;
    readonly cdnHost: string;
    readonly allowedOrigins?: string[];
    readonly webSocketUrl?: string;
    readonly webSocketCapabilityDomain?: string;
    readonly artifactResolver: IArtifactResolver;
    readonly authProvider: IMailboxAuthProvider;
    readonly sesConfigSetName: string;
    /** Optional custom domain name for this API (e.g. jmap.example.com). */
    readonly domainName?: string;
    /** ACM certificate for domainName (must be regional, in the same region as the stack/API). */
    readonly certificate?: acm.ICertificate;
}
export declare class JMapApi extends Construct {
    url: string;
    /** CNAME target to publish (API Gateway regional domain) when custom domain is enabled. */
    readonly domainTarget?: string;
    authorizerLambda: GoLambda;
    apiHandlerLambda: GoLambda;
    /** Exposed for constructs that need the underlying IHttpApi (e.g. McpApi). */
    readonly httpApi: HttpApi;
    constructor(scope: Construct, id: string, props: JMapApiProps);
    enableWebSocketPublishing(webSocketUrl: string, broadcaster: IWebSocketBroadcastPublisher): void;
}
