import { Construct } from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as apigwv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
export interface McpApiProps {
    configTable: dynamodb.ITable;
    jmapApiGateway: apigwv2.IHttpApi;
    authorizerLambda: lambda.IFunction;
    certificate: acm.ICertificate;
    domainName: string;
    scopeMap: Record<string, string[]>;
}
export declare class McpApi extends Construct {
    readonly domainTarget: string;
    constructor(scope: Construct, id: string, props: McpApiProps);
}
