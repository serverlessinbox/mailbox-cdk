import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { IMailboxAuthProvider } from '../auth/types';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import type { IAdminApiAddon } from './addons';
import type { IWebSocketBroadcastPublisher } from './websocket';
export interface AdminApiProps {
    readonly configTable: ITable;
    readonly itemTable: ITable;
    readonly auditLogTable: ITable;
    readonly changelogTable: ITable;
    readonly mailFeedbackTable: ITable;
    readonly authKeyStoreTable: ITable;
    readonly emailBucket: IBucket;
    readonly emailSubmissionQueue: IQueue;
    readonly auditEventsQueue: IQueue;
    readonly allowedOrigins?: string[];
    readonly artifactResolver: IArtifactResolver;
    readonly authProvider: IMailboxAuthProvider;
    /** Optional addons that mount extra endpoints on this Admin API (e.g. provider-specific APIs). */
    readonly addons?: IAdminApiAddon[];
    /** Optional custom domain name for this API (e.g. api.example.com). */
    readonly domainName?: string;
    /** ACM certificate for domainName (must be regional, in the same region as the stack/API). */
    readonly certificate?: acm.ICertificate;
}
export declare class AdminApi extends Construct {
    readonly url: string;
    /** CNAME target to publish (API Gateway regional domain) when custom domain is enabled. */
    readonly domainTarget?: string;
    private readonly apiHandlerLambda;
    constructor(scope: Construct, id: string, props: AdminApiProps);
    enableWebSocketPublishing(broadcaster: IWebSocketBroadcastPublisher): void;
}
