/**
 * JMAP API scope definitions for Cognito resource server
 * https://jmap.io/
 */
export declare enum Permission {
    MAIL_READ = "mail/read",
    MAIL_WRITE = "mail/write",
    MAIL_SEND = "mail/send",
    ACCOUNT_READ = "account/read",
    ALIAS_READ = "alias/read",
    ALIAS_WRITE = "alias/write",
    USER_READ = "user/read",
    CONTACTS_READ = "contacts/read",
    CONTACTS_WRITE = "contacts/write",
    ADMIN = "admin"
}
/**
 * Human-readable descriptions for each JMAP scope
 */
export declare const JMAP_SCOPE_DESCRIPTIONS: Record<Permission, string>;
