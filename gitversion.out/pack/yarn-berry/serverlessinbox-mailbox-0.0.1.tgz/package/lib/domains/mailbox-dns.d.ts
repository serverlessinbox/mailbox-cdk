import * as cdk from 'aws-cdk-lib';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { Construct } from 'constructs';
import { IMailboxDomainNames, MailboxEndpoint } from './mailbox-domains';
export type MailboxDnsCnameTargets = Partial<Record<MailboxEndpoint, string>>;
export interface MailboxDnsProps {
    readonly names: IMailboxDomainNames;
    /**
     * If provided, Route53 CNAME records will be created.
     * If omitted, CloudFormation outputs will describe the records to create externally.
     */
    readonly hostedZone?: route53.IHostedZone;
    /** CNAME values for each endpoint to publish (target hostname without protocol). */
    readonly cnameTargets: MailboxDnsCnameTargets;
    /** Default: 5 minutes */
    readonly ttl?: cdk.Duration;
    /** Output name prefix (for manual mode). Default: "MailboxDns" */
    readonly outputPrefix?: string;
}
export declare class MailboxDns extends Construct {
    constructor(scope: Construct, id: string, props: MailboxDnsProps);
}
