import { MailboxDomains, MailboxEndpoint } from './mailbox-domains';
export interface MailboxDomainContextProps {
    readonly domains: MailboxDomains;
    /** Which endpoints are considered part of this rollout (synth-time). Default: all endpoints. */
    readonly enabledEndpoints?: MailboxEndpoint[];
    /** Which enabled endpoints should be allowed as browser origins (https://...). Default: webmail + admin. */
    readonly uiEndpoints?: MailboxEndpoint[];
    /** Extra origins not derived from mailbox domains. */
    readonly extraAllowedOrigins?: string[];
}
export declare class MailboxDomainContext {
    readonly domains: MailboxDomains;
    readonly enabledEndpoints: readonly MailboxEndpoint[];
    readonly uiEndpoints: readonly MailboxEndpoint[];
    readonly extraAllowedOrigins: readonly string[];
    constructor(props: MailboxDomainContextProps);
    isEnabled(endpoint: MailboxEndpoint): boolean;
    /** Browser origins suitable for CORS allowOrigins. */
    corsAllowedOrigins(): string[];
    /** Hostnames for enabled endpoints. */
    enabledDomains(): Partial<Record<MailboxEndpoint, string>>;
}
