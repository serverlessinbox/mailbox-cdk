export declare const MAILBOX_ENDPOINTS: readonly ["ws", "api", "jmap", "cdn", "webmail", "admin", "auth", "mcp"];
export type MailboxEndpoint = typeof MAILBOX_ENDPOINTS[number];
export interface MailboxDomainNamesProps {
    /** Base domain, e.g. example.com */
    readonly domainName: string;
    /** Optional extra label between endpoint and base domain, e.g. "mailbox" -> api.mailbox.example.com */
    readonly prefix?: string;
}
export interface IMailboxDomainNames {
    readonly domainName: string;
    readonly prefix?: string;
    readonly ws: string;
    readonly api: string;
    readonly jmap: string;
    readonly cdn: string;
    readonly webmail: string;
    readonly admin: string;
    readonly auth: string;
    readonly mcp: string;
    fqdn(endpoint: MailboxEndpoint): string;
    all(): Record<MailboxEndpoint, string>;
}
export declare class MailboxDomains implements IMailboxDomainNames {
    readonly domainName: string;
    readonly prefix?: string;
    readonly ws: string;
    readonly api: string;
    readonly jmap: string;
    readonly cdn: string;
    readonly webmail: string;
    readonly admin: string;
    readonly auth: string;
    readonly mcp: string;
    constructor(props: MailboxDomainNamesProps);
    fqdn(endpoint: MailboxEndpoint): string;
    all(): Record<MailboxEndpoint, string>;
}
