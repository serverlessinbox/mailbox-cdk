import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
export interface SESEventProcessorLambdaProps {
    itemTable: ITable;
    changelogTable: ITable;
    mailFeedbackTable: ITable;
    configTable: ITable;
    emailBucket: IBucket;
    auditEventsQueue: IQueue;
    artifactResolver: IArtifactResolver;
}
export declare class SESEventProcessorLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: SESEventProcessorLambdaProps);
}
