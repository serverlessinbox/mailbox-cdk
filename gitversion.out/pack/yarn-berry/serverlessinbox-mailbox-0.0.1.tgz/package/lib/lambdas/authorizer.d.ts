import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
import { AuthPolicyName } from '../auth/types';
export interface AuthorizerLambdaProps {
    authKeyStoreTable: ITable;
    configTable: ITable;
    userPoolIssuer: string;
    artifactResolver: IArtifactResolver;
    /** Which auth policy record to load from DynamoDB (e.g. ADMIN_API, JMAP_API). */
    authPolicyName?: AuthPolicyName;
    /** Whether requests without an access token can pass authorization. */
    allowAnonymous?: boolean;
}
export declare class AuthorizerLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: AuthorizerLambdaProps);
}
