import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface BootstrapLambdaProps {
    configTable: ITable;
    jwkCacheTable: ITable;
    authKeyStoreTable: ITable;
    artifactResolver: IArtifactResolver;
}
export declare class BootstrapLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: BootstrapLambdaProps);
}
