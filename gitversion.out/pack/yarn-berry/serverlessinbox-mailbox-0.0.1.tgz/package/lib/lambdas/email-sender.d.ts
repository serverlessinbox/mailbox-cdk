import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface EmailSenderLambdaProps {
    configTable: ITable;
    itemTable: ITable;
    changelogTable: ITable;
    emailBucket: IBucket;
    sesConfigSetName: string;
    artifactResolver: IArtifactResolver;
}
export declare class EmailSenderLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: EmailSenderLambdaProps);
}
