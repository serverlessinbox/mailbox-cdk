import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface TantivyIndexerLambdaProps {
    indexBucket: IBucket;
    itemTable: ITable;
    configTable: ITable;
    changelogTable: ITable;
    artifactResolver: IArtifactResolver;
}
export declare class TantivyIndexerLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: TantivyIndexerLambdaProps);
}
