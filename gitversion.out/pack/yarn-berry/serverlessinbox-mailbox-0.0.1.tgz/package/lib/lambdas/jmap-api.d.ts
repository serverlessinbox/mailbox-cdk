import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import type { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import type { IMailboxAuthProviderBase } from '../auth/types';
export type JmapOAuthHandlerConfig = {
    issuer: string;
    tokenEndpoint: string;
    authorizationEndpoint: string;
    clientId: string;
    scopeMap: IMailboxAuthProviderBase['scopeMap'];
};
export interface ApiHandlerLambdaProps {
    configTable: ITable;
    itemTable: ITable;
    changelogTable: ITable;
    authKeyStoreTable: ITable;
    emailBucket: any;
    emailSubmissionQueue: any;
    auditEventsQueue: any;
    cdnHost: string;
    apiBaseUrl: string;
    sesConfigSetName: string;
    artifactResolver: IArtifactResolver;
    userProvisionionFunction: IFunction;
    /** Strongly-typed payload consumed by the Go handler via env.MustGet("OAUTH_HANDLER_CONFIG"). */
    oauthHandlerConfig: JmapOAuthHandlerConfig;
}
export declare class ApiHandlerLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: ApiHandlerLambdaProps);
}
