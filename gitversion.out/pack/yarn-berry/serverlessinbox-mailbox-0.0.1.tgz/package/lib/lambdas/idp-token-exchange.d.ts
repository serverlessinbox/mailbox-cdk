import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { AuthPolicyName, OAuthClientName } from '../auth/types';
export interface IdpTokenExchangeLambdaProps {
    configTable: ITable;
    auditEventsQueue?: IQueue;
    authPolicyName?: AuthPolicyName;
    oauthClientName?: OAuthClientName;
    artifactResolver: IArtifactResolver;
}
export declare class IdpTokenExchangeLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: IdpTokenExchangeLambdaProps);
}
