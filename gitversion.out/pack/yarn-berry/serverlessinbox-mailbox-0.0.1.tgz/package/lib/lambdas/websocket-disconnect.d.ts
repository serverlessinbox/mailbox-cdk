import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
export interface WebSocketDisconnectLambdaProps {
    connectionsTable: ITable;
    configTable: ITable;
    artifactResolver: IArtifactResolver;
}
export declare class WebSocketDisconnectLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: WebSocketDisconnectLambdaProps);
}
