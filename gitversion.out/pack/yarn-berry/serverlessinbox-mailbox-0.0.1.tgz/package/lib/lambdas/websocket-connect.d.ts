import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
export interface WebSocketConnectLambdaProps {
    connectionsTable: ITable;
    authKeyStoreTable: ITable;
    configTable: ITable;
    maxSubscriptions: number;
    artifactResolver: IArtifactResolver;
}
export declare class WebSocketConnectLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: WebSocketConnectLambdaProps);
}
