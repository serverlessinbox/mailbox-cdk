import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
export interface AdminApiLambdaProps {
    configTable: ITable;
    itemTable: ITable;
    auditLogTable: ITable;
    changelogTable: ITable;
    mailFeedbackTable: ITable;
    emailBucket: IBucket;
    emailSubmissionQueue: IQueue;
    auditEventsQueue: IQueue;
    artifactResolver: IArtifactResolver;
}
export declare class AdminApiLambda extends GoLambda {
    private grantStatusAccess;
    private grantSesAccess;
    private grantRoute53Access;
    private grantServiceQuotasAccess;
    private grantLicenseApiAccess;
    constructor(scope: Construct, id: string, props: AdminApiLambdaProps);
}
