import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
export interface AuthKeyStoreUpdaterLambdaProps {
    issuers: string[];
    authKeyStoreTable: ITable;
    artifactResolver: IArtifactResolver;
}
export declare class AuthKeyStoreUpdaterLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: AuthKeyStoreUpdaterLambdaProps);
}
