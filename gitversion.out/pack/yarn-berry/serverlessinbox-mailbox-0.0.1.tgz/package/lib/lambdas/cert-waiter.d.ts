import { Construct } from 'constructs';
import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface CertWaiterLambdaProps {
    artifactResolver: IArtifactResolver;
}
export declare class CertWaiterLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: CertWaiterLambdaProps);
}
