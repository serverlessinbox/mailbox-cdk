import { Construct } from 'constructs';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
export interface LicenseRefresherLambdaProps {
    configTable: ITable;
    artifactResolver: IArtifactResolver;
}
export declare class LicenseRefresherLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: LicenseRefresherLambdaProps);
}
