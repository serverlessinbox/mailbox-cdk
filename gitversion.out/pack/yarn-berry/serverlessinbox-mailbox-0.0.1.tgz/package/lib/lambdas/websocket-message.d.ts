import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
export interface WebSocketMessageLambdaProps {
    connectionsTable: ITable;
    configTable: ITable;
    itemTable: ITable;
    maxSubscriptions: number;
    websocketApiId: string;
    websocketStageName: string;
    artifactResolver: IArtifactResolver;
}
export declare class WebSocketMessageLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: WebSocketMessageLambdaProps);
}
