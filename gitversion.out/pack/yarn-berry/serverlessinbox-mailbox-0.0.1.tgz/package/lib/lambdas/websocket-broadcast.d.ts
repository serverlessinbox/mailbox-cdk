import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
export interface WebSocketBroadcastLambdaProps {
    connectionsTable: ITable;
    configTable: ITable;
    websocketApiId: string;
    websocketStageName: string;
    artifactResolver: IArtifactResolver;
}
export declare class WebSocketBroadcastLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: WebSocketBroadcastLambdaProps);
}
