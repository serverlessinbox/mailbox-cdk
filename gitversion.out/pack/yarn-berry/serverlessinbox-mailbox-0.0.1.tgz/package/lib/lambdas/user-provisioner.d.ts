import { GoLambda } from '../utils/go-lambda';
import { IArtifactResolver } from '../artifacts/artifact-resolver';
import { ITable } from 'aws-cdk-lib/aws-dynamodb';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
export interface UserProvisionerLambdaProps {
    configTable: ITable;
    itemTable: ITable;
    changelogTable: ITable;
    auditEventsQueue: IQueue;
    artifactResolver: IArtifactResolver;
}
export declare class UserProvisionerLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: UserProvisionerLambdaProps);
}
