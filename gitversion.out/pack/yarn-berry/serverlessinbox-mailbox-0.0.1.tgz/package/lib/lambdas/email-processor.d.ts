import { IBucket } from "aws-cdk-lib/aws-s3";
import { GoLambda } from "../utils/go-lambda";
import { INamedTable } from "../utils/named-table";
import { Construct } from "constructs";
import { IArtifactResolver } from "../artifacts/artifact-resolver";
import type { IWebSocketBroadcastPublisher } from "../api/websocket";
export interface EmailProcessorLambdaProps {
    configTable: INamedTable;
    itemTable: INamedTable;
    changelogTable: INamedTable;
    emailBucket: IBucket;
    artifactResolver: IArtifactResolver;
}
export declare class EmailProcessorLambda extends GoLambda {
    constructor(scope: Construct, id: string, props: EmailProcessorLambdaProps);
    enableWebSocketPublishing(broadcaster: IWebSocketBroadcastPublisher): void;
}
