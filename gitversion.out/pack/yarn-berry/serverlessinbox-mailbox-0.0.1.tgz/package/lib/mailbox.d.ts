import { Construct } from 'constructs';
import { ConfigTable, EmailBucket } from './resources';
import { Cdn } from './features/cdn-construct';
import { JMapApi } from './api/jmap-api';
import type { EmailDelivery } from './email/receiving/ses-rules';
import { AuthClientConfig } from './auth/types';
import type { IMailboxAuthProvider } from './auth/types';
import { EmailProcessorLambda } from './lambdas/email-processor';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { IHostedZone } from 'aws-cdk-lib/aws-route53';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { IDistribution } from 'aws-cdk-lib/aws-cloudfront';
import { type ServerlessInboxDeployer } from './utils/serverless-inbox-tags';
import type { MailboxKmsConfig } from './utils/kms';
export interface MailboxProps {
    readonly hostedZone?: IHostedZone;
    readonly domainName: string;
    /** Optional KMS configuration for at-rest encryption of core resources. */
    readonly kms?: MailboxKmsConfig;
    /** Preferred: provider-owned construct implementing mailbox auth configuration (+ optional admin addons). */
    readonly authProvider: IMailboxAuthProvider;
    /** Optional deployer label used for tagging (default: 'cfn'). */
    readonly deployer?: ServerlessInboxDeployer;
    /** Optional extra tags applied to all taggable resources in this construct. */
    readonly extraTags?: Record<string, string>;
    /** Extra origins to allow for CORS (e.g., local dev). UI origins are derived automatically. */
    readonly extraAllowedOrigins?: string[];
    /** Optional us-east-1 ACM certificate for CloudFront alternate domain names (e.g., cdn.<domain>). */
    readonly cloudFrontCertificate?: acm.ICertificate;
    /**
     * Whether to create the Admin UI (CloudFront + token-exchange API + OAuth client bootstrap).
     * Defaults to true.
     */
    readonly createAdminUi?: boolean;
    /**
     * Whether to create the Webmail UI (CloudFront + token-exchange API + OAuth client bootstrap).
     * Defaults to true.
     */
    readonly createWebmailUi?: boolean;
    /**
     * Whether to activate the MCP (Model Context Protocol) API at mcp.<domain>.
     * Requires an Advanced license tier. Defaults to false.
     */
    readonly activateMcp?: boolean;
    /** Optional us-east-1 ACM certificate for admin.<domain> CloudFront alternate domain name. */
    readonly adminUiCertificate?: acm.ICertificate;
    /** Optional us-east-1 ACM certificate for webmail.<domain> CloudFront alternate domain name. */
    readonly webmailUiCertificate?: acm.ICertificate;
    /** Optional regional ACM certificate for api.<domain> (Admin API custom domain). */
    readonly apiCertificate?: acm.ICertificate;
    /** Optional regional ACM certificate for jmap.<domain> (JMAP API custom domain). */
    readonly jmapCertificate?: acm.ICertificate;
    /** Optional regional ACM certificate for ws.<domain> (WebSocket push custom domain). */
    readonly wsCertificate?: acm.ICertificate;
    /**
     * When true, the Bootstrap Lambda will call SetActiveReceiptRuleSet to activate the SES receipt
     * rule set. Only one rule set can be active per account per region — this is an explicit operator
     * decision.
     */
    readonly activateReceiving?: boolean;
}
export interface MailboxOAuthClients {
    readonly adminUi?: AuthClientConfig;
    readonly jmapUi?: AuthClientConfig;
}
/**
 * Main Mailbox construct
 */
export declare class Mailbox extends Construct {
    /** @internal */
    readonly _emailBucket: EmailBucket;
    /** @internal */
    readonly _emailProcessorLambda: EmailProcessorLambda;
    /** @internal */
    readonly _configTable: ConfigTable;
    /** @internal */
    readonly _cdn: Cdn;
    private readonly artifactResolver;
    private readonly emailQueueProps;
    /** Admin UI resources (when `createAdminUi !== false`). */
    readonly adminUiBucket?: IBucket;
    readonly adminUiDistribution?: IDistribution;
    /** Webmail UI resources (when `createWebmailUi !== false`). */
    readonly webmailUiBucket?: IBucket;
    readonly webmailUiDistribution?: IDistribution;
    readonly edgeCertificate?: acm.ICertificate;
    /** Regional SAN certificate (when auto-created). Exposed for add-on constructs such as McpApi. */
    readonly regionalCertificate?: acm.ICertificate;
    /** @internal */
    readonly _jmapApi: JMapApi;
    /** OAuth clients created by this construct (only when enabled). */
    readonly oauthClients: MailboxOAuthClients;
    /** @internal */
    _emailDelivery(): EmailDelivery;
    constructor(scope: Construct, id: string, props: MailboxProps);
}
