import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IArtifactResolver } from '@serverlessinbox/mailbox';
export interface CognitoCustomMessageLambdaProps {
    artifactResolver: IArtifactResolver;
    /** Optional login URL to include in templates. */
    loginUrl?: string;
    /** Optional support/contact line appended to emails. */
    supportText?: string;
}
/**
 * Artifact-based Lambda for Cognito Custom Message trigger.
 *
 * Expects an artifact at: `lambdas/cognito-custom-message.zip`
 * with handler: `index.handler`.
 */
export declare class CognitoCustomMessageLambda extends Construct {
    readonly fn: IFunction;
    constructor(scope: Construct, id: string, props: CognitoCustomMessageLambdaProps);
}
