import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IArtifactResolver } from '@serverlessinbox/mailbox';
export interface CognitoBootstrapUserLambdaProps {
    artifactResolver: IArtifactResolver;
}
/**
 * Artifact-based TypeScript Lambda for Cognito bootstrap user custom resource.
 *
 * Expects an artifact at: `lambdas/cognito-bootstrap-user.zip`
 * with handler: `index.handler`.
 */
export declare class CognitoBootstrapUserLambda extends Construct {
    readonly fn: IFunction;
    constructor(scope: Construct, id: string, props: CognitoBootstrapUserLambdaProps);
}
