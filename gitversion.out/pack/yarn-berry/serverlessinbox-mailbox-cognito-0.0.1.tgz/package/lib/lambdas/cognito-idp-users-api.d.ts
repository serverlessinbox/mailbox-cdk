import { Function as LambdaFunction, IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IArtifactResolver } from '@serverlessinbox/mailbox';
export interface CognitoIdpUsersApiLambdaProps {
    artifactResolver: IArtifactResolver;
    /** Cognito user pool ID to manage. */
    userPoolId: string;
    /** Audit event queue URL (SQS). */
    auditEventsQueueUrl: string;
}
/**
 * Artifact-based TypeScript Lambda for Cognito user management endpoints.
 *
 * Expects an artifact at: `lambdas/cognito-idp-users-api.zip`
 * with handler: `index.handler`.
 */
export declare class CognitoIdpUsersApiLambda extends Construct {
    readonly function: LambdaFunction;
    readonly fn: IFunction;
    constructor(scope: Construct, id: string, props: CognitoIdpUsersApiLambdaProps);
}
