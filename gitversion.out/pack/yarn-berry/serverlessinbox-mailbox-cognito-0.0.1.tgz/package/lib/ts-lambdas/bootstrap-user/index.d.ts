type CloudFormationCustomResourceEvent = {
    RequestType: 'Create' | 'Update' | 'Delete';
    ResponseURL: string;
    StackId: string;
    RequestId: string;
    ResourceType: string;
    LogicalResourceId: string;
    PhysicalResourceId?: string;
    ResourceProperties: Record<string, any>;
};
export declare const handler: (event: CloudFormationCustomResourceEvent) => Promise<void>;
export {};
