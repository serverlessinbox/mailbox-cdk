export declare const DEFAULT_ADMIN_CREATE_USER_SUBJECT = "Welcome {{username}}";
export declare const DEFAULT_ADMIN_CREATE_USER_MESSAGE: string;
export declare const DEFAULT_FORGOT_PASSWORD_SUBJECT = "Reset your password";
export declare const DEFAULT_FORGOT_PASSWORD_MESSAGE: string;
