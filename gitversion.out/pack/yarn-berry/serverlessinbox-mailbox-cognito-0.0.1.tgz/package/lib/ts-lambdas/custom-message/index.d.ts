type CognitoCustomMessageEvent = {
    triggerSource: string;
    userName?: string;
    request?: {
        codeParameter?: string;
        usernameParameter?: string;
    };
    response: {
        emailSubject?: string;
        emailMessage?: string;
        smsMessage?: string;
    };
};
export declare const handler: (event: CognitoCustomMessageEvent) => Promise<CognitoCustomMessageEvent>;
export {};
