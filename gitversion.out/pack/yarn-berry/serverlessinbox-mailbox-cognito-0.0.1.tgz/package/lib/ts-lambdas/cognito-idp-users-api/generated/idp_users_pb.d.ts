import type { GenFile, GenMessage, GenService } from "@bufbuild/protobuf/codegenv2";
import type { Timestamp } from "@bufbuild/protobuf/wkt";
import type { Message } from "@bufbuild/protobuf";
/**
 * Describes the file idp_users.proto.
 */
export declare const file_idp_users: GenFile;
/**
 * @generated from message idp_users.v1.IdpUser
 */
export type IdpUser = Message<"idp_users.v1.IdpUser"> & {
    /**
     * @generated from field: string username = 1;
     */
    username: string;
    /**
     * @generated from field: bool enabled = 2;
     */
    enabled: boolean;
    /**
     * @generated from field: optional string user_status = 3;
     */
    userStatus?: string | undefined;
    /**
     * @generated from field: optional google.protobuf.Timestamp created_at = 4;
     */
    createdAt?: Timestamp | undefined;
    /**
     * @generated from field: optional google.protobuf.Timestamp modified_at = 5;
     */
    modifiedAt?: Timestamp | undefined;
    /**
     * Best-effort attributes snapshot (provider-specific; e.g. email, sub).
     *
     * @generated from field: map<string, string> attributes = 6;
     */
    attributes: {
        [key: string]: string;
    };
};
/**
 * Describes the message idp_users.v1.IdpUser.
 * Use `create(IdpUserSchema)` to create a new message.
 */
export declare const IdpUserSchema: GenMessage<IdpUser>;
/**
 * @generated from message idp_users.v1.ListIdpUsersRequest
 */
export type ListIdpUsersRequest = Message<"idp_users.v1.ListIdpUsersRequest"> & {
    /**
     * @generated from field: optional int32 page_size = 1;
     */
    pageSize?: number | undefined;
    /**
     * @generated from field: optional string page_token = 2;
     */
    pageToken?: string | undefined;
    /**
     * @generated from field: optional string filter = 3;
     */
    filter?: string | undefined;
};
/**
 * Describes the message idp_users.v1.ListIdpUsersRequest.
 * Use `create(ListIdpUsersRequestSchema)` to create a new message.
 */
export declare const ListIdpUsersRequestSchema: GenMessage<ListIdpUsersRequest>;
/**
 * @generated from message idp_users.v1.ListIdpUsersResponse
 */
export type ListIdpUsersResponse = Message<"idp_users.v1.ListIdpUsersResponse"> & {
    /**
     * @generated from field: repeated idp_users.v1.IdpUser users = 1;
     */
    users: IdpUser[];
    /**
     * @generated from field: string next_page_token = 2;
     */
    nextPageToken: string;
};
/**
 * Describes the message idp_users.v1.ListIdpUsersResponse.
 * Use `create(ListIdpUsersResponseSchema)` to create a new message.
 */
export declare const ListIdpUsersResponseSchema: GenMessage<ListIdpUsersResponse>;
/**
 * @generated from message idp_users.v1.GetIdpUserRequest
 */
export type GetIdpUserRequest = Message<"idp_users.v1.GetIdpUserRequest"> & {
    /**
     * @generated from field: string username = 1;
     */
    username: string;
};
/**
 * Describes the message idp_users.v1.GetIdpUserRequest.
 * Use `create(GetIdpUserRequestSchema)` to create a new message.
 */
export declare const GetIdpUserRequestSchema: GenMessage<GetIdpUserRequest>;
/**
 * @generated from message idp_users.v1.GetIdpUserResponse
 */
export type GetIdpUserResponse = Message<"idp_users.v1.GetIdpUserResponse"> & {
    /**
     * @generated from field: idp_users.v1.IdpUser user = 1;
     */
    user?: IdpUser | undefined;
};
/**
 * Describes the message idp_users.v1.GetIdpUserResponse.
 * Use `create(GetIdpUserResponseSchema)` to create a new message.
 */
export declare const GetIdpUserResponseSchema: GenMessage<GetIdpUserResponse>;
/**
 * @generated from message idp_users.v1.CreateIdpUserRequest
 */
export type CreateIdpUserRequest = Message<"idp_users.v1.CreateIdpUserRequest"> & {
    /**
     * @generated from field: string username = 1;
     */
    username: string;
    /**
     * @generated from field: optional string email = 2;
     */
    email?: string | undefined;
    /**
     * @generated from field: string password = 3;
     */
    password: string;
    /**
     * Optional desired enabled state. If omitted, defaults to true.
     *
     * @generated from field: optional bool enabled = 4;
     */
    enabled?: boolean | undefined;
    /**
     * Optional group memberships (best-effort).
     *
     * @generated from field: repeated string groups = 5;
     */
    groups: string[];
};
/**
 * Describes the message idp_users.v1.CreateIdpUserRequest.
 * Use `create(CreateIdpUserRequestSchema)` to create a new message.
 */
export declare const CreateIdpUserRequestSchema: GenMessage<CreateIdpUserRequest>;
/**
 * @generated from message idp_users.v1.CreateIdpUserResponse
 */
export type CreateIdpUserResponse = Message<"idp_users.v1.CreateIdpUserResponse"> & {
    /**
     * @generated from field: idp_users.v1.IdpUser user = 1;
     */
    user?: IdpUser | undefined;
};
/**
 * Describes the message idp_users.v1.CreateIdpUserResponse.
 * Use `create(CreateIdpUserResponseSchema)` to create a new message.
 */
export declare const CreateIdpUserResponseSchema: GenMessage<CreateIdpUserResponse>;
/**
 * @generated from message idp_users.v1.SetIdpUserEnabledRequest
 */
export type SetIdpUserEnabledRequest = Message<"idp_users.v1.SetIdpUserEnabledRequest"> & {
    /**
     * @generated from field: string username = 1;
     */
    username: string;
    /**
     * @generated from field: bool enabled = 2;
     */
    enabled: boolean;
};
/**
 * Describes the message idp_users.v1.SetIdpUserEnabledRequest.
 * Use `create(SetIdpUserEnabledRequestSchema)` to create a new message.
 */
export declare const SetIdpUserEnabledRequestSchema: GenMessage<SetIdpUserEnabledRequest>;
/**
 * @generated from message idp_users.v1.SetIdpUserEnabledResponse
 */
export type SetIdpUserEnabledResponse = Message<"idp_users.v1.SetIdpUserEnabledResponse"> & {};
/**
 * Describes the message idp_users.v1.SetIdpUserEnabledResponse.
 * Use `create(SetIdpUserEnabledResponseSchema)` to create a new message.
 */
export declare const SetIdpUserEnabledResponseSchema: GenMessage<SetIdpUserEnabledResponse>;
/**
 * @generated from message idp_users.v1.SetIdpUserPasswordRequest
 */
export type SetIdpUserPasswordRequest = Message<"idp_users.v1.SetIdpUserPasswordRequest"> & {
    /**
     * @generated from field: string username = 1;
     */
    username: string;
    /**
     * @generated from field: string password = 2;
     */
    password: string;
    /**
     * @generated from field: optional bool permanent = 3;
     */
    permanent?: boolean | undefined;
};
/**
 * Describes the message idp_users.v1.SetIdpUserPasswordRequest.
 * Use `create(SetIdpUserPasswordRequestSchema)` to create a new message.
 */
export declare const SetIdpUserPasswordRequestSchema: GenMessage<SetIdpUserPasswordRequest>;
/**
 * @generated from message idp_users.v1.SetIdpUserPasswordResponse
 */
export type SetIdpUserPasswordResponse = Message<"idp_users.v1.SetIdpUserPasswordResponse"> & {};
/**
 * Describes the message idp_users.v1.SetIdpUserPasswordResponse.
 * Use `create(SetIdpUserPasswordResponseSchema)` to create a new message.
 */
export declare const SetIdpUserPasswordResponseSchema: GenMessage<SetIdpUserPasswordResponse>;
/**
 * IdpUsersService provides operations for managing IdP users (provider-specific).
 *
 * @generated from service idp_users.v1.IdpUsersService
 */
export declare const IdpUsersService: GenService<{
    /**
     * ListIdpUsers retrieves IdP users with pagination.
     *
     * @generated from rpc idp_users.v1.IdpUsersService.ListIdpUsers
     */
    listIdpUsers: {
        methodKind: "unary";
        input: typeof ListIdpUsersRequestSchema;
        output: typeof ListIdpUsersResponseSchema;
    };
    /**
     * GetIdpUser retrieves a specific IdP user by username.
     *
     * @generated from rpc idp_users.v1.IdpUsersService.GetIdpUser
     */
    getIdpUser: {
        methodKind: "unary";
        input: typeof GetIdpUserRequestSchema;
        output: typeof GetIdpUserResponseSchema;
    };
    /**
     * CreateIdpUser creates a new IdP user (admin-driven onboarding).
     *
     * @generated from rpc idp_users.v1.IdpUsersService.CreateIdpUser
     */
    createIdpUser: {
        methodKind: "unary";
        input: typeof CreateIdpUserRequestSchema;
        output: typeof CreateIdpUserResponseSchema;
    };
    /**
     * SetIdpUserEnabled enables/disables an IdP user.
     *
     * @generated from rpc idp_users.v1.IdpUsersService.SetIdpUserEnabled
     */
    setIdpUserEnabled: {
        methodKind: "unary";
        input: typeof SetIdpUserEnabledRequestSchema;
        output: typeof SetIdpUserEnabledResponseSchema;
    };
    /**
     * SetIdpUserPassword sets a user's password (admin-driven; avoids email dependency).
     *
     * @generated from rpc idp_users.v1.IdpUsersService.SetIdpUserPassword
     */
    setIdpUserPassword: {
        methodKind: "unary";
        input: typeof SetIdpUserPasswordRequestSchema;
        output: typeof SetIdpUserPasswordResponseSchema;
    };
}>;
