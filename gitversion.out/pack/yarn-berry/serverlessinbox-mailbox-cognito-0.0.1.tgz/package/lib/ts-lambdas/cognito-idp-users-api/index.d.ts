export declare const handler: (event: import("@serverlessinbox/mailbox-admin-api").ApiGatewayV2EventLike) => Promise<import("@serverlessinbox/mailbox-admin-api").ApiGatewayV2ResultLike>;
