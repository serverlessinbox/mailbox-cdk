import { SQSClient } from '@aws-sdk/client-sqs';
import type { AuditEvent } from '@serverlessinbox/mailbox-admin-api';
export interface AuditEmitter {
    emit(evt: AuditEvent): Promise<void>;
}
export declare class SqsAuditEmitter implements AuditEmitter {
    private readonly queueUrl;
    private readonly sqs;
    constructor(queueUrl: string, opts?: {
        sqs?: SQSClient;
    });
    emit: (evt: AuditEvent) => Promise<void>;
    private toAuditWriterBody;
}
