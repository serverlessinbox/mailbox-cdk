import { IdpUsersServiceClient } from './index';
export interface ClientConfig {
    baseUrl: string;
    authorization?: string;
    /** Custom fetch function for request interceptors, token refresh, retry logic, etc. */
    fetch?: typeof fetch;
}
/**
 * Unified client for all services
 */
export declare class Client {
    readonly idpUsers: IdpUsersServiceClient;
    constructor(config: ClientConfig);
}
