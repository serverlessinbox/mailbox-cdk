import type { Message } from '@bufbuild/protobuf';
import type { ListIdpUsersRequest, ListIdpUsersResponse, GetIdpUserRequest, GetIdpUserResponse, CreateIdpUserRequest, CreateIdpUserResponse, SetIdpUserEnabledRequest, SetIdpUserEnabledResponse, SetIdpUserPasswordRequest, SetIdpUserPasswordResponse } from './idp_users_pb';
type ListIdpUsersRequestData = Omit<ListIdpUsersRequest, keyof Message>;
type GetIdpUserRequestData = Omit<GetIdpUserRequest, keyof Message>;
type CreateIdpUserRequestData = Omit<CreateIdpUserRequest, keyof Message>;
type SetIdpUserEnabledRequestData = Omit<SetIdpUserEnabledRequest, keyof Message>;
type SetIdpUserPasswordRequestData = Omit<SetIdpUserPasswordRequest, keyof Message>;
export interface IdpUsersServiceClientConfig {
    endpoint: string;
    authorization?: string;
    /** Custom fetch function for request interceptors, token refresh, retry logic, etc. */
    fetch?: typeof fetch;
}
/**
 * IdpUsersService provides operations for managing IdP users (provider-specific).
 */
export declare class IdpUsersServiceClient {
    private readonly endpoint;
    private readonly authorization?;
    private readonly fetch;
    constructor(config: IdpUsersServiceClientConfig);
    /**
     * ListIdpUsers retrieves IdP users with pagination.
     */
    listIdpUsers(request?: ListIdpUsersRequestData): Promise<ListIdpUsersResponse>;
    /**
     * GetIdpUser retrieves a specific IdP user by username.
     */
    getIdpUser(request: GetIdpUserRequestData): Promise<GetIdpUserResponse>;
    /**
     * CreateIdpUser creates a new IdP user (admin-driven onboarding).
     */
    createIdpUser(request: CreateIdpUserRequestData): Promise<CreateIdpUserResponse>;
    /**
     * SetIdpUserEnabled enables/disables an IdP user.
     */
    setIdpUserEnabled(request: SetIdpUserEnabledRequestData): Promise<SetIdpUserEnabledResponse>;
    /**
     * SetIdpUserPassword sets a user's password (admin-driven; avoids email dependency).
     */
    setIdpUserPassword(request: SetIdpUserPasswordRequestData): Promise<SetIdpUserPasswordResponse>;
}
export * from './idp_users_pb';
