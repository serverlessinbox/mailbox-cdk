import { CognitoIdentityProviderClient } from '@aws-sdk/client-cognito-identity-provider';
import type { AdminAuthContext, AuditContext, HandlerContext } from '@serverlessinbox/mailbox-admin-api';
import type { CreateIdpUserRequest, CreateIdpUserResponse, GetIdpUserRequest, GetIdpUserResponse, ListIdpUsersRequest, ListIdpUsersResponse, SetIdpUserEnabledRequest, SetIdpUserEnabledResponse, SetIdpUserPasswordRequest, SetIdpUserPasswordResponse } from './generated/idp_users_pb';
import type { IdpUsersServiceHandlers } from './generated/idp_users_service';
type IdpUsersContext = HandlerContext<AdminAuthContext, AuditContext>;
export declare class CognitoIdpUsersService implements IdpUsersServiceHandlers<AdminAuthContext, AuditContext> {
    private readonly cognito;
    private readonly userPoolId;
    constructor(client?: CognitoIdentityProviderClient, userPoolId?: string);
    private static requireUserPoolIdFromEnv;
    listIdpUsers(_ctx: IdpUsersContext, req: ListIdpUsersRequest): Promise<ListIdpUsersResponse>;
    getIdpUser(ctx: IdpUsersContext, req: GetIdpUserRequest): Promise<GetIdpUserResponse>;
    createIdpUser(ctx: IdpUsersContext, req: CreateIdpUserRequest): Promise<CreateIdpUserResponse>;
    setIdpUserEnabled(ctx: IdpUsersContext, req: SetIdpUserEnabledRequest): Promise<SetIdpUserEnabledResponse>;
    setIdpUserPassword(ctx: IdpUsersContext, req: SetIdpUserPasswordRequest): Promise<SetIdpUserPasswordResponse>;
    private static mapListUser;
    private static mapAdminGetUser;
    private static attrsToMap;
}
export {};
