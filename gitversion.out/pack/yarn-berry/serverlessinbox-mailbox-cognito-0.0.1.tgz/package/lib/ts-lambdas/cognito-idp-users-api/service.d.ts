import type { AdminAuthContext, AuditContext, ServiceSpec } from '@serverlessinbox/mailbox-admin-api';
import { type IdpUsersServiceHandlers } from './generated/idp_users_service';
import { CognitoIdpUsersService } from './idp-users.service';
import { IdpUsersRequestValidator } from './idp-users.validation';
export type CognitoIdpUsersServiceSpecOptions = {
    service?: IdpUsersServiceHandlers<AdminAuthContext, AuditContext>;
    validator?: IdpUsersRequestValidator;
};
export declare function createCognitoIdpUsersServiceSpec(opts?: CognitoIdpUsersServiceSpecOptions): ServiceSpec<AdminAuthContext, AuditContext>;
export { CognitoIdpUsersService };
