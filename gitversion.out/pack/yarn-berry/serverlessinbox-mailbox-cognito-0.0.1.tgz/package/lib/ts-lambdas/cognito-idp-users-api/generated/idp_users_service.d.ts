import type { ListIdpUsersRequest, ListIdpUsersResponse, GetIdpUserRequest, GetIdpUserResponse, CreateIdpUserRequest, CreateIdpUserResponse, SetIdpUserEnabledRequest, SetIdpUserEnabledResponse, SetIdpUserPasswordRequest, SetIdpUserPasswordResponse } from './idp_users_pb';
export type HandlerContext<TAuth = unknown, TAudit = unknown> = {
    auth: TAuth;
    audit: TAudit;
    requestId?: string;
};
export interface IdpUsersServiceHandlers<TAuth = unknown, TAudit = unknown> {
    listIdpUsers(ctx: HandlerContext<TAuth, TAudit>, req: ListIdpUsersRequest): Promise<ListIdpUsersResponse>;
    getIdpUser(ctx: HandlerContext<TAuth, TAudit>, req: GetIdpUserRequest): Promise<GetIdpUserResponse>;
    createIdpUser(ctx: HandlerContext<TAuth, TAudit>, req: CreateIdpUserRequest): Promise<CreateIdpUserResponse>;
    setIdpUserEnabled(ctx: HandlerContext<TAuth, TAudit>, req: SetIdpUserEnabledRequest): Promise<SetIdpUserEnabledResponse>;
    setIdpUserPassword(ctx: HandlerContext<TAuth, TAudit>, req: SetIdpUserPasswordRequest): Promise<SetIdpUserPasswordResponse>;
}
export declare const IdpUsersServiceRuntime: {
    readonly basePath: "/idp-users";
    readonly serviceName: "IdpUsersService";
    readonly methods: {
        readonly ListIdpUsers: {
            readonly name: "ListIdpUsers";
            readonly handlerName: "listIdpUsers";
            readonly requestSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<ListIdpUsersRequest>;
            readonly responseSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<ListIdpUsersResponse>;
        };
        readonly GetIdpUser: {
            readonly name: "GetIdpUser";
            readonly handlerName: "getIdpUser";
            readonly requestSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<GetIdpUserRequest>;
            readonly responseSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<GetIdpUserResponse>;
        };
        readonly CreateIdpUser: {
            readonly name: "CreateIdpUser";
            readonly handlerName: "createIdpUser";
            readonly requestSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<CreateIdpUserRequest>;
            readonly responseSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<CreateIdpUserResponse>;
        };
        readonly SetIdpUserEnabled: {
            readonly name: "SetIdpUserEnabled";
            readonly handlerName: "setIdpUserEnabled";
            readonly requestSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<SetIdpUserEnabledRequest>;
            readonly responseSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<import("@bufbuild/protobuf").Message<"idp_users.v1.SetIdpUserEnabledResponse">>;
        };
        readonly SetIdpUserPassword: {
            readonly name: "SetIdpUserPassword";
            readonly handlerName: "setIdpUserPassword";
            readonly requestSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<SetIdpUserPasswordRequest>;
            readonly responseSchema: import("@bufbuild/protobuf/codegenv2").GenMessage<import("@bufbuild/protobuf").Message<"idp_users.v1.SetIdpUserPasswordResponse">>;
        };
    };
};
