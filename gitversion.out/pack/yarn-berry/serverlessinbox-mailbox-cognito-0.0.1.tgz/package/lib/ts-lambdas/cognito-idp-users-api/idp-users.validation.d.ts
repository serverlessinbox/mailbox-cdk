import type { CreateIdpUserRequest, GetIdpUserRequest, ListIdpUsersRequest, SetIdpUserEnabledRequest, SetIdpUserPasswordRequest } from './generated/idp_users_pb';
export declare class IdpUsersRequestValidator {
    validateListIdpUsers: import("@serverlessinbox/mailbox-admin-api").Validator<ListIdpUsersRequest>;
    validateGetIdpUser: import("@serverlessinbox/mailbox-admin-api").Validator<GetIdpUserRequest>;
    validateCreateIdpUser: import("@serverlessinbox/mailbox-admin-api").Validator<CreateIdpUserRequest>;
    validateSetIdpUserEnabled: import("@serverlessinbox/mailbox-admin-api").Validator<SetIdpUserEnabledRequest>;
    validateSetIdpUserPassword: import("@serverlessinbox/mailbox-admin-api").Validator<SetIdpUserPasswordRequest>;
    private assertListIdpUsers;
    private assertHasUsername;
    private assertCreateIdpUser;
    private assertSetIdpUserPassword;
}
