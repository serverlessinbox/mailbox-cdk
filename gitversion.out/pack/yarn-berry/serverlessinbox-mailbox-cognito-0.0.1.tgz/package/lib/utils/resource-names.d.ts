import type { IConstruct } from 'constructs';
export interface PhysicalNameOptions {
    maxLength?: number;
}
/**
 * Create a stable physical name following the existing scheme:
 * `<account>-<sanitize(stackName)>-<suffix>`.
 */
export declare function makePhysicalName(scope: IConstruct, suffix: string, options?: PhysicalNameOptions): string;
export declare function slugifyLabel(label: string): string;
