import { Permission } from '@serverlessinbox/mailbox';
export declare enum CognitoScope {
    MAIL_READ = "mail.read",
    MAIL_WRITE = "mail.write",
    MAIL_SEND = "mail.send",
    ACCOUNT_READ = "account.read",
    ALIAS_READ = "alias.read",
    ALIAS_WRITE = "alias.write",
    USER_READ = "user.read",
    CONTACTS_READ = "contacts.read",
    CONTACTS_WRITE = "contacts.write",
    ADMIN = "admin"
}
export declare const CognitoScopeToPermissions: Record<CognitoScope, Permission[]>;
export declare const PermissionToCognitoScope: Record<Permission, CognitoScope>;
