import { IUserPool } from 'aws-cdk-lib/aws-cognito';
import { Construct } from 'constructs';
import { IArtifactResolver } from '@serverlessinbox/mailbox';
export interface BootstrapUserProps {
    readonly userPool: IUserPool;
    /** Defaults to `"admin"` if not provided. */
    readonly username?: string;
    /** Email address for the bootstrap user. Required unless `temporaryPassword` is set. */
    readonly email?: string;
    readonly groups: string[];
    /**
     * One-time temporary bootstrap password. When set, the user is created in
     * FORCE_CHANGE_PASSWORD state and must change it on first login.
     * This is a temporary credential only — never use for permanent passwords.
     */
    readonly temporaryPassword?: string;
    /** Optional artifact resolver (defaults to context via `createArtifactResolverFromContext`). */
    readonly artifactResolver?: IArtifactResolver;
    /** If true, Cognito will send an invite email (default: false / SUPPRESS). */
    readonly sendInvite?: boolean;
}
export declare class BootstrapUser extends Construct {
    constructor(scope: Construct, id: string, props: BootstrapUserProps);
}
