import { HttpApi } from 'aws-cdk-lib/aws-apigatewayv2';
import { HttpLambdaAuthorizer } from 'aws-cdk-lib/aws-apigatewayv2-authorizers';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import type { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IAdminApiAddon, IArtifactResolver } from '@serverlessinbox/mailbox';
export interface CognitoIdpUsersAuthorizationConfig {
    readonly adminGroups: string[];
    readonly userGroups: string[];
}
export interface ICognitoIdpUsersPoolConfig {
    readonly userPoolId: string;
    grantAdminAccess(fn: IFunction): void;
    fetchAuthorizationConfig?(): CognitoIdpUsersAuthorizationConfig;
}
export interface CognitoIdpUsersAdminApiAddonProps {
    readonly artifactResolver: IArtifactResolver;
    /** Audit events queue used by the existing audit-writer lambda. */
    readonly auditEventsQueue: IQueue;
    /** Cognito pool integration (used for pool id + granting permissions). */
    readonly pool: ICognitoIdpUsersPoolConfig;
    /** Optional base path; defaults to `/idp-users`. */
    readonly basePath?: string;
    /** Optional UI config to be merged into admin-ui config.json. */
    readonly uiConfig?: Record<string, unknown>;
}
/**
 * Mounts a Cognito-specific IdP user management API under the main Admin API.
 *
 * Routes: `${basePath}/{proxy+}` (ANY)
 *
 * The actual handler logic lives in a provider-owned Lambda (TypeScript/Node.js, artifact-based).
 */
export declare class CognitoIdpUsersAdminApiAddon extends Construct implements IAdminApiAddon {
    readonly basePath: string;
    uiConfig?: Record<string, unknown>;
    /** @internal */
    private readonly _lambdaConstruct;
    /** The underlying CDK construct wrapping the Lambda function. */
    readonly lambdaFunction: Construct;
    constructor(scope: Construct, id: string, props: CognitoIdpUsersAdminApiAddonProps);
    addRoutes(api: HttpApi, authorizer: HttpLambdaAuthorizer): void;
}
