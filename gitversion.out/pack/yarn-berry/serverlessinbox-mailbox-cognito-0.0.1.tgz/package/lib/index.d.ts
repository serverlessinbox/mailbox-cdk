/**
 * @serverlessinbox/mailbox-cognito - CDK Construct Library for Cognito-backed Mailbox Auth
 */
export { MailboxUserPool } from './auth/mailbox-user-pool';
export type { MailboxUserPoolProps, MailboxUserPoolCognitoDomain, MailboxUserPoolCustomDomain, MailboxUserPoolDomain, MailboxUserPoolAuthorizationConfig, MailboxUserPoolCustomMessageConfig, ProvisionHeadlessClientConfig, } from './auth/mailbox-user-pool';
export { BootstrapUser } from './auth/bootstrap-user';
export type { BootstrapUserProps } from './auth/bootstrap-user';
export { MailboxCognitoCustomMessage } from './auth/custom-message';
export type { MailboxCognitoCustomMessageProps } from './auth/custom-message';
export { CognitoIdpUsersAdminApiAddon } from './api/cognito-idp-users-addon';
export type { CognitoIdpUsersAdminApiAddonProps, CognitoIdpUsersAuthorizationConfig, ICognitoIdpUsersPoolConfig, } from './api/cognito-idp-users-addon';
export { COGNITO_LAMBDAS_ARTIFACT_PACKAGE } from './artifacts';
